package com.siot.IamportRestClient.response;

public class EmptyResponse {
}
